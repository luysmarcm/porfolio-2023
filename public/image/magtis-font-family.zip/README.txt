To learn more about the font family and its license, visit https://www.fontmirror.com/magtis

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://crmrkt.com/JxbA64.
To learn more about the font, visit https://www.behance.net/gallery/126589835/MAGTIS-Free-Font.